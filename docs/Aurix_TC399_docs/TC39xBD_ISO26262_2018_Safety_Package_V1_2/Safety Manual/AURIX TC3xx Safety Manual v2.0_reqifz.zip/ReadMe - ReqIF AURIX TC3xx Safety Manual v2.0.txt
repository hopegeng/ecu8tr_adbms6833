ReadMe for file 'AURIX TC3xx Safety Manual v2.0.reqifz'
=======================================================
Date: 2021-05-21

Infineon provides the ReqIFz file as an optional addon to the officially released 'AURIX TC3xx Safety Manual.pdf' file.
The ReqIF format generated for the Safety Manual is not qualified according to ISO 26262, therefore
Infineon Technologies AG disclaims any liability in connection with the use of this information.

Content of the file reflects structure as well as content of 'AURIX TC3xx Safety Manual v2.0.pdf' chapters 3, 4, 5 and 6.
The ReqIF file is validated against ReqIF standard using 'Consequent ReqIF Validation' (v.0.14.0.201811270400) shipped with ReqIF-Studio (v2.4.1.201811270950).
Compatibility is tested for Doors Classic (v9.6.1.11) using PTC Integrity Requirements Connector (v3.3) for import.
Import into other RE-tool should work, however import into other RE-tools than Doors Classic (v9.6.1.11) is done at the user's own risk.

For compatibility reasons SPEC-OBJECT attribute definitions are following the 'ReqIF Implementation Guide' (Version 1.4.4 as of January 3rd, 2017) published by the PROSTEP IVIP Association.
Currently the following (ReqIF) system attributes are supported:
- ReqIF.Name
- ReqIF.Text
- ReqIF.ChapterName
- ReqIF.ForeignID

Revision History
----------------
2021-05-21:
  - Initial version